﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.IO;
using System.Text.RegularExpressions;

namespace 局域网群聊
{
    /// <summary>
    /// MainWindow.xaml 的交互逻辑
    /// </summary>
    public partial class MainWindow : Window
    {
        private TcpListener listener;//定义一个私有监听
        private Dictionary<String, TcpClient> socketList;
        private bool tag = true;
        private StringBuilder charList;
        public MainWindow()
        {
            InitializeComponent();
           
        }
       
        private void Button_Click(object sender, RoutedEventArgs e)
        {

            listBox.Items.Clear();
            txt_show.Text = "";
            int port = 8888;
            //创建服务端，并且启动 
            try
            {
                listener = new TcpListener(IPAddress.Parse(ipAddress()), port);
                listener.Start();

                
            }
            catch (Exception ex)
            {
                MessageBox.Show("服务器启动失败， 原因：" + ex.Message);
               
                return;
            }
            txt_show.Text = "服务器启动成功，访问IP：" + ipAddress() + " 端口号：" + port;

            //记录住连接的客户端 
            socketList = new Dictionary<String, TcpClient>();
            charList = new StringBuilder();

            //使用多线程，用于多个客户端接入 
            Thread th = new Thread(new ThreadStart(executeTask));
            th.Start();
        }
        public void executeTask()
        {
            while (tag)
            {
                //等待用户连接 
                TcpClient client = null;
                try
                {
                    client = listener.AcceptTcpClient();
                }
                catch (Exception)
                {
                }
                Thread th = new Thread(executeRead);
                th.Start((Object)client);
            }
        }
        public void executeRead(Object pamars)
        {
            //永久监听读取客户端 
            TcpClient client = pamars as TcpClient;
            while (tag)
            {
               
                    NetworkStream ns = client.GetStream();

                    StreamReader sr = new StreamReader(ns);
                    String msg = String.Empty;
                    String people = String.Empty;

                    try
                    {
                        msg = sr.ReadLine();
                        if (msg.IndexOf("<clientName>") != -1)
                        {
                            msg = Regex.Split(msg, "=")[1];
                            listBox.Items.Add(msg);
                            charList.Append(msg).Append("<@>");
                            socketList.Add(msg, client);
                            msg = "<br>欢迎【" + msg + "】光临<br>";
                        }
                        txt_show.AppendText(msg.Replace("<br>", "\r\n"));
                        sendMsg(String.Empty, msg);
                    }
                    catch (Exception)
                    {
                        //MessageBox.Show(ex.Message.ToString()); 
                        break;
                    }
                
            }
        }
        public void sendMsg(String target, String msg)
        {
            if (String.Empty != target)
            {
                TcpClient client = socketList[target];
                StreamWriter sw = new StreamWriter(client.GetStream());
                sw.WriteLine(msg);
                sw.Flush();
            }
            else
            {
                Dictionary<String, TcpClient>.KeyCollection keyColl = socketList.Keys;
                foreach (String name in keyColl)
                {
                    StreamWriter sw = new StreamWriter(socketList[name].GetStream());
                    sw.WriteLine(msg + "<@=@>" + charList.ToString());
                    sw.Flush();
                }
            }
        }
        public String ipAddress()
        {
            IPAddress[] address = Dns.GetHostAddresses(Dns.GetHostName());
            return address[2].ToString();
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            e.Cancel = false;
            if (tag)
                tag = false;
            if (listener != null)
                listener.Stop();
        }
    }
}
